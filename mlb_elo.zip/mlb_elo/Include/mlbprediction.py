# -*- coding: utf-8 -*-
"""
Jeffrey Tung
Class: CS 677 - Spring 2
Date: 4/16/21
Final Project: MLB playoff
-->Using logistic regression classifier trained with an inputted season, predict current season's playoff
teams
"""
import os
import sys
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from dataprep import *
from datapredict import *

FILENAME = 'mlb_elo'
INPUT_DIR = r'..\Include'
MLB_FILE = os.path.join(INPUT_DIR, FILENAME + '.csv')
SEASON = 2007
CURR_SEASON = 2021
SEASON_PROGRESS = .15 #if CURR_SEASON is 2020, SEASON_PROGRESS >= .15, due to Marlins and Cardinals missing first part of season due to Covid




#set pandas dataframe options
pd.set_option('display.max_columns', 500)
pd.options.mode.chained_assignment = None

#Load csv file to pandas dataframe
try:
    MLB_df = load_data(MLB_FILE)
    
except Exception as e:
    print(e)
    print('failed to compute data for file: ', FILENAME)
    sys.exit(1)
    
#Retrieve 2 seasons from MLB_df, current season and first season to train data 
try:
    reg_season, playoffs, playoff_teams, curr_reg_season, curr_playoffs, curr_playoff_teams = retrieve_seasons(
        MLB_df, SEASON, CURR_SEASON)
    
except Exception as e:
    print(e)
    print('failed to compute data for file: ', FILENAME)
    sys.exit(1)
    
#retrieve current season's progress constant
try:
    #Most current prediction parameter up until 4/27
    SEASON_PROGRESS = (curr_reg_season.shape[0]) / (reg_season.shape[0])
    #4/21 Prediction parameter
    #SEASON_PROGRESS = .12875
    
except Exception as e:
    print(e)
    print('Failed to retrieve current seasons progress')
    sys.exit(1)
    
#train years back and season progress in logistic regression and return the best season to use
#to build logistic regression model set to best_year as the most accurate year to use to predict
try:
    #start comparison from 2 years back, starting 2019 to eliminate shortened 2020 COVID season
    best_year = prev_year_train(MLB_df, CURR_SEASON-2, (CURR_SEASON-2)- SEASON, SEASON_PROGRESS)
    
    #train season progress with previous season
    #best_progress, best_year = prev_year_train(MLB_df, CURR_SEASON-2, (CURR_SEASON-2) - SEASON, 1)
    
except Exception as e:
    print(e)
    print('Failed to train logistic regression with prior seasons and season pregression')
    sys.exit(1)
    
#Retrieve 2 seasons from MLB_df, current season and best prediction season  
try:
    reg_season, playoffs, playoff_teams, curr_reg_season, curr_playoffs, curr_playoff_teams = retrieve_seasons(
        MLB_df, best_year, CURR_SEASON)
    
except Exception as e:
    print(e)
    print('failed to compute data for file: ', FILENAME)
    sys.exit(1)

#separate seasons into teams with different feature means for both season
try:
    teams = playoff_class(home_away(reg_season, SEASON_PROGRESS), playoff_teams)
    curr_teams = playoff_class(home_away(curr_reg_season, 1.0), curr_playoff_teams)
    
except Exception as e:
    print(e)
    print('failed to extract list of teams from: ', FILENAME)
    sys.exit(1)

#train features in logistic regression and return the features with that most effectively predicts
#playoff class

#try:
    #feature_train(MLB_df, best_year, CURR_SEASON-2, 'home', SEASON_PROGRESS)
    #feature_train(MLB_df, best_year, CURR_SEASON-2, 'away', SEASON_PROGRESS)

#except Exception as e:
    #print(e)
    #print('failed to train features with accuracy')
    #sys.exit(1)

#generate playoff prediction based off of home and away games, with the overall prediction
#consisting of ensemble prediction consisting of both home and away playoff prediction. i.e. a
#team is predicted to make the playoffs if that team is predicted to be a playoff team based off of 
#both their home games and their away games
try:
    #predict playoff class based off of home games
    playoff_pred_home = log_regression(teams, curr_teams,'home')
    #predict playoff class based off of away games
    playoff_pred_away = log_regression(teams, curr_teams,'away')
    #combine the two predictions together
    playoff_pred = playoff_pred_home.join(playoff_pred_away)
    #form overall playoff class based off of the home and away prediction
    playoff_pred['Prediction'] = np.where((playoff_pred['Predicted_home'] == 1) & 
                                          (playoff_pred['Predicted_away'] == 1), 1, 0)
    
except Exception as e:
    print(e)
    print('failed to calculate accuracies for logistic regression.')
    sys.exit(1)    
    
try:
    #convert SEASON_PROGRESS constant to percentage
    progress = SEASON_PROGRESS * 100
    #extract list of playoff teams from prediction
    playoff_teams = playoff_pred[playoff_pred['Prediction'] == 1].index
    #extract list of bubble teams from prediction
    bubble_teams = playoff_pred[((playoff_pred['Predicted_home'] == 1) & (playoff_pred['Predicted_away'] == 0)) |
                                ((playoff_pred['Predicted_home'] == 0) & (playoff_pred['Predicted_away'] == 1))].index
    print('Through %.3f percent of games played in the ' % (progress) + str(CURR_SEASON) + 
          ' season, using data from the ' + str(best_year) + ' season,\nI predict these teams to make the playoffs:')
    for i in range(len(playoff_teams)):
        print(playoff_teams[i])
    print('I also predict ' + str(10-len(playoff_teams)) + 
          ' of these teams on the bubble of my predictions to fill the remaining '+
          str(10-len(playoff_teams)) +' playoff spots:')
    for i in range(len(bubble_teams)):
        print(bubble_teams[i])
    
    
except Exception as e:
    print(e)
    print('failed to print accuracy statement for ' + str(CURR_SEASON) + ' season.')
    sys.exit(1)
