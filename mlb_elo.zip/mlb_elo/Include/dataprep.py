import pandas as pd
import numpy as np

def load_data(file):
    """load data into pandas dataframe from file argument and extract 4 dataframes consisting of
       previous and current season's regular season games and playoff games from year and current
       argument. Function also returns 2 numpy arrays of previous and current season's playoff_teams
    """
    df = pd.read_csv(file)
    #eliminate elo-ratings since rating column depicts a more in-depth projection based off of preseason 
    #team projections as well as starting pitchers
    df = df.drop(['elo1_pre', 'elo2_pre', 'elo_prob1', 'elo_prob2','elo1_post', 'elo2_post'], axis=1)
    #extract the season of year argument and separate into regular season and playoff dataframe
    df['playoff'] = np.where(df['playoff'].isnull(), 0, df['playoff'])
    index = df[df['season'] == 2020].index
    df = df.drop(index)
    return df

def retrieve_seasons(df, year, current):
    df_prev = df[df['season'] == year]
    df_reg = df_prev[df_prev['playoff'] == 0]
    df_playoff = df_prev[df_prev['playoff'] != 0]
    #extract a numpy array of playoff teams
    playoff_teams = np.unique(np.concatenate((df_playoff['team1'].unique(), df_playoff['team2'].unique())))
    #extract the season of current year and separate into regular season and playoff dataframe    
    df_curr = df[df['season'] == current]
    index = df_curr[df_curr['rating1_post'].isnull()].index
    #eliminate all rows of games that haven't been played yet in current season
    df_curr = df_curr.drop(index)
    df_curr['playoff'] = np.where(df_curr['playoff'].isnull(), 0, df_curr['playoff'])
    df_curr_reg = df_curr[df_curr['playoff'] == 0]
    df_curr_playoff = df_curr[df_curr['playoff'] != 0]
    #extract a numpy array of playoff teams
    curr_playoff_teams = np.unique(np.concatenate((df_curr_playoff['team1'].unique(), df_curr_playoff['team2'].unique())))
    #return previous and current years' regular season & playoffs dataframe as well as numpy array of playoff teams
    return df_reg, df_playoff, playoff_teams, df_curr_reg, df_curr_playoff, curr_playoff_teams

def home_away(df, season_progression):
    """separate dataframe into separate teams playing home and away games (team1 = home team, team2 = away team),
       add 'playoff' column where 1 signifies the team is a playoff team and 0  signifies the team missed playoffs.
       Function returns the newly combined dataframe of teams.
    """
    #full season of 162 games for 30 teams result in 4860 games, using season_progression to extract current season's 
    #progression to predict, with every game involving 2 teams, total games played in regular season is 2430
    progress = int(df.shape[0] * season_progression)
    #generate 2 new dataframes of teams from home and away games of mean values from each columns for each team
    home_df = df.tail(progress).groupby(['team1']).mean()
    away_df = df.tail(progress).groupby(['team2']).mean()

    #Flip team 1 with team 2 in away dataframe so team 1 data is consistent with home dataframe with _a
    #signifying away stats 
    away_df.columns = ['season', 'neutral', 'rating2_pre_a', 'rating1_pre_a', 'pitcher2_rgs_a',
                       'pitcher1_rgs_a', 'pitcher2_adj_a', 'pitcher1_adj_a', 'rating_prob2_a', 'rating_prob1_a',
                       'rating2_post_a', 'rating1_post_a', 'score2_a', 'score1_a']
    home_df = home_df.drop(['season','neutral'], axis=1)
    away_df = away_df.drop(['season','neutral'], axis=1)
    
    #combine 2 dataframes together
    combine_df = home_df.join(away_df)
    
    #generate 'score_diff' column of average score difference  
    combine_df['score_diff'] = combine_df['score1'] - combine_df['score2']
    combine_df['score_diff_a'] = combine_df['score1_a'] - combine_df['score2_a']    
    return combine_df

def playoff_class(df, playoff):
    #generate 'playoff' column of playoff class labels depicting if a team made the playoffs.
    df['playoff'] = 0
    for i in range(len(playoff)):
        df['playoff'] = np.where((df.index == playoff[i]) | (df['playoff'] == 1), 1, 0)
    return df