import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import LabelEncoder
from dataprep import *

def log_regression(df, df_curr, h_or_a):
    """Perform logistic regression classification to predict the playoff teams from df_curr argument,
       function will use features and models from df and fit logistic regression models to df and apply
       it to df_curr to generate a playoff class for either home or away games provided by the h_or_a arg
    """
    if h_or_a == 'home':
        features = ['rating1_pre', 'rating2_pre', 'pitcher1_rgs', 'pitcher2_rgs', 'pitcher1_adj',
                    'pitcher2_adj', 'rating_prob1', 'rating_prob2', 'rating1_post', 'rating2_post',
                    'score1', 'score2', 'score_diff']
    elif h_or_a == 'away':
        features = ['rating1_pre_a', 'rating2_pre_a', 'pitcher1_rgs_a', 'pitcher2_rgs_a', 'pitcher1_adj_a',
                    'pitcher2_adj_a', 'rating_prob1_a', 'rating_prob2_a', 'rating1_post_a', 'rating2_post_a',
                    'score1_a', 'score2_a', 'score_diff_a']
    else:
        print('Specify home or away analysis: h_or_a argument must be either "home" or "away"')
        return df
    #Set previous season to training data
    #define X dataset features
    X_train = df[features]
    #define Y dataset features
    le = LabelEncoder()
    Y_train = le.fit_transform(df['playoff'].values)
    #Set Current season to testing data
    X_test = df_curr[features]
    Y_test = le.fit_transform(df_curr['playoff'].values)
    #define logistic regression model and fit it to current season
    log_reg = LogisticRegression(max_iter=1000)
    log_reg.fit(X_train, Y_train)
    #predefine column name depending on h_or_a arg
    predicted = 'Predicted_' + h_or_a
    #predict current season playoff outcome
    df_curr[predicted] = log_reg.predict(X_test)
    if h_or_a == 'home':
        df_comp = df_curr[['playoff', predicted]]
    else:
        df_comp = df_curr[predicted]
    return df_comp

def accuracies(df):
    """Function calculates the overall accuracies of predicting playoff outcomes of the logistic
       regression model, returns the accuracy in percentage points.
    """
    accuracy = ((df[(df['playoff'] == 0) & (df['Prediction'] == 0)].count()[0]) +
                (df[(df['playoff'] == 1) & (df['Prediction'] == 1)].count()[0])) / (len(df.playoff))
    return accuracy * 100

def prev_year_train(df, current, years_back, season_progress):
    """Function trains previous years and/or season_progress from 10%, 20%,..., 90% to prediction
       accuracy, if season_progress arg is 1, then the function will train both season_progress and
       previous seasons used for fitting regression model and generate accuracy graph. If 
       season_progress arg is not 1, function will only train previous years with the current season_progress.
    """
    #create start year
    start = current - years_back
    #'1' means 10% through season, '2' means 20%, etc.
    if season_progress == 1:
        #create prediction accuracy dictionary with corresponding progress through an MLB season    
        pred_accuracies = {
            '1': [],
            '2': [],
            '3': [],
            '4': [],
            '5': [],
            '6': [],
            '7': [],
            '8': [],
            '9': []
        }
        #2 for loops to train season progress and previous season
        for i in range(start, current):
            for k in range(1,10):
                progress = k / 10
                reg_season, playoffs, playoff_teams, curr_reg_season, curr_playoffs, curr_playoff_teams = retrieve_seasons(
                    df, i, current)
                teams = playoff_class(home_away(reg_season, progress), playoff_teams)
                curr_teams = playoff_class(home_away(curr_reg_season, progress), curr_playoff_teams)
                playoff_pred_home = log_regression(teams, curr_teams,'home')
                playoff_pred_away = log_regression(teams, curr_teams,'away')
                playoff_pred = playoff_pred_home.join(playoff_pred_away)
                playoff_pred['Prediction'] = np.where((playoff_pred['Predicted_home'] == 1) & 
                                                      (playoff_pred['Predicted_away'] == 1), 1, 0)
                pred_accuracies[str(k)].append(accuracies(playoff_pred))
        #create plot consisting of 9 different lines (season progress) of accuracies with previous seasons
        ax = plt.gca()
        plt.plot(range(start, current), pred_accuracies['1'], color='red', marker='o', markerfacecolor='red', 
                 markersize=5, label='10% games played')
        plt.plot(range(start, current), pred_accuracies['2'], color='orange', marker='o', markerfacecolor='orange', 
                 markersize=5, label='20% games played')
        plt.plot(range(start, current), pred_accuracies['3'], color='yellow', marker='o', markerfacecolor='yellow', 
                 markersize=5, label='30% games played')
        plt.plot(range(start, current), pred_accuracies['4'], color='green', marker='o', markerfacecolor='green', 
                 markersize=5, label='40% games played')
        plt.plot(range(start, current), pred_accuracies['5'], color='blue', marker='o', markerfacecolor='blue', 
                 markersize=5, label='50% games played')
        plt.plot(range(start, current), pred_accuracies['6'], color='cyan', marker='o', markerfacecolor='cyan', 
                 markersize=5, label='60% games played')
        plt.plot(range(start, current), pred_accuracies['7'], color='purple', marker='o', markerfacecolor='purple', 
                 markersize=5, label='70% games played')
        plt.plot(range(start, current), pred_accuracies['8'], color='brown', marker='o', markerfacecolor='brown', 
                 markersize=5, label='80% games played')
        plt.plot(range(start, current), pred_accuracies['9'], color='pink', marker='o', markerfacecolor='pink', 
                 markersize=5, label='90% games played')
        plt.title('Playoff Prediction Accuracies vs. Previous Seasons & Season Progress')
        plt.xlabel('MLB Season Used to predict')
        plt.ylabel('Prediction Accuracy')
        plt.legend(bbox_to_anchor=(1,1), loc='upper left')
        plt.show()
        #retrieve best progress and best year based off of prediction accuracies
        pred_df = pd.DataFrame.from_dict(pred_accuracies)
        best_progress = pred_df.max().idxmax()
        best_year = current - (years_back - (pred_df[best_progress].idxmax(axis=0)))
        return (int(best_progress) * .1), best_year
    else:
        #create prediction accuracy dictionary with corresponding progress through an MLB season    
        pred_accuracies = []
        for i in range(start, current):
            reg_season, playoffs, playoff_teams, curr_reg_season, curr_playoffs, curr_playoff_teams = retrieve_seasons(
                df, i, current)
            teams = playoff_class(home_away(reg_season, season_progress), playoff_teams)
            curr_teams = playoff_class(home_away(curr_reg_season, season_progress), curr_playoff_teams)
            playoff_pred_home = log_regression(teams, curr_teams,'home')
            playoff_pred_away = log_regression(teams, curr_teams,'away')
            playoff_pred = playoff_pred_home.join(playoff_pred_away)
            playoff_pred['Prediction'] = np.where((playoff_pred['Predicted_home'] == 1) & 
                                                  (playoff_pred['Predicted_away'] == 1), 1, 0)
            pred_accuracies.append(accuracies(playoff_pred))
        pred_np = np.array(pred_accuracies)
        best_index = np.where(pred_np == np.amax(pred_np))
        best_index = best_index[-1]
        best_year = current - (years_back - best_index)
        return best_year[-1]
    
def feature_train(df, training_year, testing_year, h_or_a, season_progress):  
    """Function trains each feature to the accuracy by eliminating a feature from the logistic
       regression model.
    """
    #retrieve testing and training season
    reg_season, playoffs, playoff_teams, curr_reg_season, curr_playoffs, curr_playoff_teams = retrieve_seasons(
        df, training_year, testing_year)
    #retrieve list of team  and their feature averages for testing and training season
    df_train = playoff_class(home_away(reg_season, season_progress), playoff_teams)
    df_test = playoff_class(home_away(curr_reg_season, season_progress), curr_playoff_teams)
    Accuracy = []
    num_features = int((len(df_test.columns) - 1)/2)
    #Populate the accuracy array with each feature eliminated
    for i in range(num_features):
        #retrieve features, minus the feature in the i index
        if h_or_a == 'home':
            features = ['rating1_pre', 'rating2_pre', 'pitcher1_rgs', 'pitcher2_rgs', 'pitcher1_adj',
                        'pitcher2_adj', 'rating_prob1', 'rating_prob2', 'rating1_post', 'rating2_post',
                        'score1', 'score2', 'score_diff']
        elif h_or_a == 'away':
            features = ['rating1_pre_a', 'rating2_pre_a', 'pitcher1_rgs_a', 'pitcher2_rgs_a', 'pitcher1_adj_a',
                        'pitcher2_adj_a', 'rating_prob1_a', 'rating_prob2_a', 'rating1_post_a', 'rating2_post_a',
                        'score1_a', 'score2_a', 'score_diff_a']
        else:
            print('Specify home or away analysis: h_or_a argument must be either "home" or "away"')
            return df        
        features.pop(i)
        #define X dataset features
        X_train = df_train[features]
        #define Y dataset features
        le = LabelEncoder()
        Y_train = le.fit_transform(df_train['playoff'].values)
        #Set Current season to testing data
        X_test = df_test[features]
        Y_test = le.fit_transform(df_test['playoff'].values)
        log_reg = LogisticRegression(max_iter=1000)
        log_reg.fit(X_train, Y_train)
        Accuracy.append(log_reg.score(X_test, Y_test))
        
    overall_accuracy = .84
    feature_index = []
    for i in range(len(Accuracy)):
        if Accuracy[i] < overall_accuracy:
            feature_index.append(i)
    
    return Accuracy